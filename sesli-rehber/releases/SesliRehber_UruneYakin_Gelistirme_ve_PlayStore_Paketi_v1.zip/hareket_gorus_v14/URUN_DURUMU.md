# Sesli Rehber / Hareket Görüş — ürün durumu

Bu paket Samsung Galaxy S24 Ultra (arm64-v8a) hedeflenerek hazırlanmıştır.

## Çalışan çekirdek

- Camera2 NDK ile 1280×720 kamera akışı
- Dikey, tam ekran canlı görüntü
- Hareketli bölge tespiti ve 12 hedefe kadar takip
- Görüntü düzleminde yaklaşık hız/ivme ve rota izi
- Yerel CSV kaydı; görüntü cihazdan dışarı gönderilmez
- Kamera izninin çalışma zamanında istenmesi

## Pilot geliştirme kapsamı

Aşağıdaki yetenekler ürün gereksinimidir ancak bu pakette güvenilir saha doğrulaması tamamlanmamıştır:

- Araç, duvar, kaldırım, çukur ve engel sınıflandırması
- Kamera + ivmeölçer + jiroskop + pusula + GPS füzyonu
- Sesli adres alma ve yaya rotası
- Sol/sağ yönlü ses ve titreşim uyarıları
- Düşük güven durumunda “DUR, bastonla doğrula” güvenlik davranışı
- “Hey Rehber” sürekli uyandırma ve çevrimdışı Türkçe niyet motoru

Bu uygulama beyaz bastonun, rehber köpeğin veya profesyonel yönelim-hareketlilik eğitiminin yerine geçmez. Saha doğrulaması tamamlanmadan bağımsız güvenlik sistemi olarak kullanılmamalıdır.

## Yayına kalan zorunlu işler

1. S24 Ultra üzerinde kamera yönü, izin, ısınma ve en az 30 dakikalık dayanım testi.
2. Gün/gece/yağmur koşullarında etiketli veriyle yanlış pozitif ve kaçırma ölçümü.
3. Çukur ve kaldırım için gerçek derinlik modeli veya kalibre edilmiş monoküler derinlik ağı.
4. TalkBack erişilebilirlik testi ve kör kullanıcılarla kontrollü pilot çalışma.
5. Play Console kapalı test, çökme/ANR kontrolü ve veri güvenliği beyanının doğrulanması.
6. Aynı uygulamanın üzerine güncelleme isteniyorsa önceki imzalama anahtarı.
