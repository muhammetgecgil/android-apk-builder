# Kapalı test planı

## Kurulum

- Samsung Galaxy S24 Ultra / Android 16
- Temiz kurulum ve güncelleme kurulumu ayrı test edilir.
- Kamera izni reddetme, sonradan verme ve kalıcı reddetme senaryoları uygulanır.

## Fonksiyon

- Dikey/yatay telefon yönü
- Ön/arka ışık, düşük ışık ve güçlü güneş
- Sabit telefon ve yürüyüş sırasında kamera hareketi
- Hareketli insan/araç ile sabit duvar/kaldırım ayrımı
- Yanlış alarm, kaçırma ve uyarı gecikmesi kaydı

## Güvenlik kabul kriterleri

- Düşük güvenli tahmin kesin nesne adı olarak seslendirilmez.
- Kritik belirsizlikte “DUR, bastonla doğrula” uyarısı üretilir.
- Kamera kapalı, izin yok veya kare akışı donmuşsa kullanıcı açıkça uyarılır.
- Navigasyon ve engel uyarısı çelişirse engel uyarısı önceliklidir.
- Uygulama hiçbir ekranda “bastonun yerine geçer” iddiası taşımaz.

## Performans

- 30 dakika kesintisiz çalışma
- Çökme ve ANR: 0
- Kamera donması: 0
- Pil ve yüzey sıcaklığı kaydı
- Sesli uyarı başlangıç gecikmesi hedefi: 500 ms’den kısa

