# Uygulama adı

Sesli Rehber — Güvenli Yaya Pilot

# Kısa açıklama

Görme engelli kullanıcılar için kamera tabanlı çevre farkındalığı pilotu.

# Tam açıklama

Sesli Rehber, görme engelli kullanıcıların çevredeki hareketi fark etmesine yardımcı olmak amacıyla geliştirilen erişilebilir bir Android pilot uygulamasıdır.

Mevcut sürüm kameradaki hareketli bölgeleri cihaz üzerinde işler, hedefleri takip eder ve yaklaşık görüntü düzlemi hız/ivme bilgisi üretir. Görüntüler sunucuya gönderilmez.

Planlanan güvenli yaya modu; sesli adres alma, yaya rotası, araç/duvar/kaldırım/çukur uyarıları, telefon sensörleriyle güven artırımı ve yönlü ses/titreşim geri bildirimi içerir. Bu yetenekler saha doğrulaması tamamlanana kadar pilot olarak sunulur.

Önemli: Uygulama beyaz bastonun, rehber köpeğin veya profesyonel yönelim ve hareketlilik desteğinin yerine geçmez. Trafik ve yol koşullarında yalnızca ek yardımcı olarak kullanılmalıdır.

# Kategori

Araçlar / Erişilebilirlik

# İletişim

Geliştirici: Muhammet Geçgil

