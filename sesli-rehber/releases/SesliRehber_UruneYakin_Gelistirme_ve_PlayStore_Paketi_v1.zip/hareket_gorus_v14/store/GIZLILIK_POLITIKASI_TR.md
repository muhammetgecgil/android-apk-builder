# Gizlilik Politikası

Son güncelleme: 26 Ağustos 2026

Sesli Rehber’in mevcut pilot sürümü kamera görüntüsünü cihaz üzerinde işler. Kamera kareleri geliştirici sunucularına gönderilmez ve uygulama tarafından galeriye kaydedilmez.

Uygulama kamera iznini canlı çevre analizi için kullanır. Kullanıcı kayıt özelliğini başlatırsa yalnızca hedef kimliği, zaman, görüntü koordinatı ve yaklaşık hız/ivme değerlerinden oluşan CSV dosyası uygulamanın özel depolama alanına yazılır.

Mevcut sürüm reklam, üçüncü taraf analiz SDK’sı veya kullanıcı hesabı içermez. Kişisel veri satılmaz ve reklam amacıyla paylaşılmaz.

Gelecekte konum, mikrofon, acil durum kişileri veya bulut tabanlı yapay zekâ eklenirse bu politika, Play Console veri güvenliği formu ve uygulama içi açık rıza ekranları yayın öncesinde güncellenecektir.

Silme: Uygulamanın verileri Android Ayarlar > Uygulamalar > Sesli Rehber > Depolama > Verileri sil yoluyla kaldırılabilir. Uygulamanın kaldırılması da yerel uygulama verilerini siler.

