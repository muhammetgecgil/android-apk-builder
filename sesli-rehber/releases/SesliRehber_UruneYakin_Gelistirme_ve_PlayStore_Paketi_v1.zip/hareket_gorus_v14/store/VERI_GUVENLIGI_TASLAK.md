# Play Console Veri Güvenliği Taslağı

Bu cevaplar yalnızca mevcut V14 çekirdeği içindir ve Play Console’a girilmeden önce gerçek yayın paketiyle tekrar doğrulanmalıdır.

- Veri toplanıyor mu: Hayır (geliştirici sunucusuna aktarım yok).
- Veri paylaşılıyor mu: Hayır.
- Kamera: Geçici olarak cihaz üzerinde işlenir; sunucuya gönderilmez.
- Uygulama etkinliği/analitik: Yok.
- Reklam kimliği: Yok.
- Hesap oluşturma: Yok.
- Veri silme: Android uygulama verilerini silme veya uygulamayı kaldırma.
- Aktarımda şifreleme: Sunucu aktarımı bulunmadığı için uygulanamaz.

Konum, mikrofon, WhatsApp, acil durum kişileri veya çevrimiçi yapay zekâ etkinleştirildiğinde bu taslak geçersiz olur ve yeniden doldurulmalıdır.

