HAREKET GORUS V14 HD

- NativeActivity + Camera2 NDK.
- Kamera okuyucu 1280x720; portrait isleme 540x960.
- Tam ekran center-crop kamera goruntusu.
- Sistem cubuklari immersive tam ekran modunda gizlenir.
- DONDER / IZ SIL / HEDEF / KAYIT butonlari yarı saydam HUD olarak kamera goruntusunun uzerindedir.
- 12 hedefe kadar takip, 120 noktalik rota izi, px/s hiz ve px/s2 ivme.
- CSV kayit app externalDataPath altina yazilir.
